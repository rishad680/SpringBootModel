package com.example.demo;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	
	public String customer(){
		return "My first REst Service";
	}
	
	public String test(){
		return "welcome";
	}

	@Autowired
	public CustomerRepository customerRepository;
	public  void generateCustomer(Customer cust) {
		// TODO Auto-generated method stub
		customerRepository.save(cust);

}

	public List<Customer> getAllEmployee() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	public Customer getCustomerById(Long cid) {
		Optional<Customer> ocust=customerRepository.findById(cid);
		return ocust.get();
		
		
	}

	public void deleteCustomerById(Long cid) {
		// TODO Auto-generated method stub
		customerRepository.deleteById(cid);
	}

	public void updateCustomerById(Customer c, Long cid) {
		// TODO Auto-generated method stub
		Optional<Customer> cust=customerRepository.findById(cid);
		if(cust.isPresent())
		{
			c.setCustomerId(cid);
			customerRepository.save(c);
		}
		else {
			
		}
		
	}
}
