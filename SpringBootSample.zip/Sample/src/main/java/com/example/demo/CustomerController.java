package com.example.demo;


import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	
	
	@Autowired
	public CustomerService customerservice;
	
	
	@GetMapping(value="/customer")
	public String welcome() {
		return customerservice.customer();
	}

	@GetMapping(value="/greet")
	public String test() {
		return customerservice.test();
	}
	
	@PostMapping(value="customer/create")
	public void Post(@RequestBody Customer cust) {
		customerservice.generateCustomer(cust);
	}
	
	@GetMapping("/customer/customers")
	public List<Customer> getAllCustomer() {
		return customerservice.getAllEmployee();
	}
	
	@GetMapping("/customer/{custId}")
	public Customer getCustomerById(@PathVariable("custId") Long cid) {
		return customerservice.getCustomerById(cid);
		
	}
	
	@DeleteMapping("/customer/delete/{custId}")
	public void deleteCustomerById(@PathVariable("custId") Long cid) {
		customerservice.deleteCustomerById(cid);
	}
	
	@PutMapping("customer/update/{custId}")
	public Customer updateCustomerById(@RequestBody Customer c,@PathVariable("custId") Long cid) {
		customerservice.updateCustomerById(c,cid);
		return customerservice.getCustomerById(cid);
	}
}
